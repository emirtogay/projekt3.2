import java.util.ArrayList;
import java.util.List;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        class Student {
            public String fname;
            public String lname;
            public String indexnumber;
            public String email;
            public String adress;
            public List<Integer> grades;
            public List<StudentGroup> groups;

            public Student(String fname, String lname, String indexnumber, String email, String adress) {
                this.fname = fname;
                this.lname = lname;
                this.indexnumber = indexnumber;
                this.email = email;
                this.adress = adress;
                this.grades = new ArrayList<>();
                this.groups = new ArrayList<>();
            }
            public class StudentGroup {
                public String nazwa;
                public List<Student> students;
                public StudentGroup(String nazwa) {
                    this.nazwa = nazwa;
                    this.students = new ArrayList<>();
                }
            }

        }
    }
}